import { useState, useEffect, useCallback } from 'react';
import type { TeamChallenge, ShameEntry, AdminSettings, AdminState } from '@/types';

const STORAGE_KEYS = {
  challenges: 'witc_challenges',
  shame: 'witc_shame',
  settings: 'witc_settings',
  admin: 'witc_admin',
  initialized: 'witc_initialized',
};

const DEFAULT_SETTINGS: AdminSettings = {
  defaultResponseHours: 72,
  admissionFee: 100,
  removalFee: 500,
  whatsappNumber: '+1 901 860 4456',
  telegramLink: '',
};

const INITIAL_CHALLENGES: TeamChallenge[] = [
  {
    id: 'demo-1',
    challengerTeam: 'Rooster Squad',
    challengerDiscord: 'rooster#1234',
    challengerTwitch: 'roostersquad',
    targetTeam: 'Clutch Kings',
    targetDiscord: 'clutchkings#5678',
    game: 'Call of Duty',
    battleType: '5v5 Search & Destroy',
    stakeAmount: 100,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    responseDeadlineHours: 72,
    status: 'pending',
  },
  {
    id: 'demo-2',
    challengerTeam: 'Phoenix Fire',
    challengerDiscord: 'phoenix#9999',
    targetTeam: 'Ghost Reapers',
    targetDiscord: 'ghostreapers#3333',
    targetTwitch: 'ghostreapers',
    game: 'Valorant',
    battleType: '3v3 Competitive',
    stakeAmount: 100,
    createdAt: new Date(Date.now() - 172800000).toISOString(),
    responseDeadlineHours: 48,
    status: 'pending',
  },
  {
    id: 'demo-3',
    challengerTeam: 'Alpha Wolves',
    challengerTwitch: 'alphawolves',
    targetTeam: 'Shadow Clan',
    targetDiscord: 'shadowclan#7777',
    game: 'Fortnite',
    battleType: '2v2 Build Battle',
    stakeAmount: 100,
    createdAt: new Date(Date.now() - 259200000).toISOString(),
    responseDeadlineHours: 24,
    status: 'confirmed',
    acceptedAt: new Date(Date.now() - 180000000).toISOString(),
  },
];

const INITIAL_SHAME: ShameEntry[] = [
  {
    id: 'shame-1',
    teamName: 'Chicken Runners',
    discord: 'chickenrunners#0001',
    twitch: 'chickenrunners',
    game: 'Call of Duty',
    battleType: '5v5 Search & Destroy',
    challengerTeam: 'Rooster Squad',
    expiredAt: new Date(Date.now() - 604800000).toISOString(),
    removalFee: 500,
    paidRemoval: false,
  },
  {
    id: 'shame-2',
    teamName: 'Scared Eagles',
    discord: 'scaredeagles#2222',
    game: 'Apex Legends',
    battleType: '3v3 Arena',
    challengerTeam: 'Predator Pack',
    expiredAt: new Date(Date.now() - 1209600000).toISOString(),
    removalFee: 500,
    paidRemoval: false,
  },
];

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const stored = localStorage.getItem(key);
    if (stored) return JSON.parse(stored);
  } catch { /* ignore */ }
  return fallback;
}

function saveToStorage(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch { /* ignore */ }
}

export function useChallenges() {
  const [challenges, setChallenges] = useState<TeamChallenge[]>(() => {
    const initialized = localStorage.getItem(STORAGE_KEYS.initialized);
    if (!initialized) {
      localStorage.setItem(STORAGE_KEYS.initialized, 'true');
      saveToStorage(STORAGE_KEYS.challenges, INITIAL_CHALLENGES);
      return INITIAL_CHALLENGES;
    }
    return loadFromStorage<TeamChallenge[]>(STORAGE_KEYS.challenges, INITIAL_CHALLENGES);
  });

  useEffect(() => {
    saveToStorage(STORAGE_KEYS.challenges, challenges);
  }, [challenges]);

  const addChallenge = useCallback((challenge: Omit<TeamChallenge, 'id' | 'createdAt' | 'status'>) => {
    const newChallenge: TeamChallenge = {
      ...challenge,
      id: `challenge-${Date.now()}`,
      createdAt: new Date().toISOString(),
      status: 'pending',
    };
    setChallenges(prev => [newChallenge, ...prev]);
    return newChallenge;
  }, []);

  const updateChallenge = useCallback((id: string, updates: Partial<TeamChallenge>) => {
    setChallenges(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  }, []);

  const deleteChallenge = useCallback((id: string) => {
    setChallenges(prev => prev.filter(c => c.id !== id));
  }, []);

  const deleteChallengesBulk = useCallback((ids: string[]) => {
    setChallenges(prev => prev.filter(c => !ids.includes(c.id)));
  }, []);

  const moveToConfirmed = useCallback((id: string) => {
    setChallenges(prev => prev.map(c => 
      c.id === id ? { ...c, status: 'confirmed' as const, acceptedAt: new Date().toISOString() } : c
    ));
  }, []);

  const moveToExpired = useCallback((id: string) => {
    setChallenges(prev => prev.map(c => 
      c.id === id ? { ...c, status: 'expired' as const } : c
    ));
  }, []);

  const moveToShame = useCallback((challenge: TeamChallenge) => {
    const shameEntry: ShameEntry = {
      id: `shame-${Date.now()}`,
      teamName: challenge.targetTeam,
      discord: challenge.targetDiscord,
      twitch: challenge.targetTwitch,
      platformId: challenge.targetPlatformId,
      game: challenge.game,
      battleType: challenge.battleType,
      challengerTeam: challenge.challengerTeam,
      expiredAt: new Date().toISOString(),
      removalFee: 150,
      paidRemoval: false,
      notes: challenge.notes,
    };
    return shameEntry;
  }, []);

  const activeChallenges = challenges.filter(c => c.status === 'pending');
  const confirmedChallenges = challenges.filter(c => c.status === 'confirmed');
  const expiredChallenges = challenges.filter(c => c.status === 'expired');

  return {
    challenges,
    activeChallenges,
    confirmedChallenges,
    expiredChallenges,
    addChallenge,
    updateChallenge,
    deleteChallenge,
    deleteChallengesBulk,
    moveToConfirmed,
    moveToExpired,
    moveToShame,
  };
}

export function useShame() {
  const [shameEntries, setShameEntries] = useState<ShameEntry[]>(() => {
    const initialized = localStorage.getItem(STORAGE_KEYS.initialized);
    if (!initialized) {
      saveToStorage(STORAGE_KEYS.shame, INITIAL_SHAME);
      return INITIAL_SHAME;
    }
    return loadFromStorage<ShameEntry[]>(STORAGE_KEYS.shame, INITIAL_SHAME);
  });

  useEffect(() => {
    saveToStorage(STORAGE_KEYS.shame, shameEntries);
  }, [shameEntries]);

  const addShameEntry = useCallback((entry: Omit<ShameEntry, 'id' | 'expiredAt'>) => {
    const newEntry: ShameEntry = {
      ...entry,
      id: `shame-${Date.now()}`,
      expiredAt: new Date().toISOString(),
    };
    setShameEntries(prev => [newEntry, ...prev]);
    return newEntry;
  }, []);

  const updateShameEntry = useCallback((id: string, updates: Partial<ShameEntry>) => {
    setShameEntries(prev => prev.map(e => e.id === id ? { ...e, ...updates } : e));
  }, []);

  const deleteShameEntry = useCallback((id: string) => {
    setShameEntries(prev => prev.filter(e => e.id !== id));
  }, []);

  const deleteShameEntriesBulk = useCallback((ids: string[]) => {
    setShameEntries(prev => prev.filter(e => !ids.includes(e.id)));
  }, []);

  const markAsPaid = useCallback((id: string) => {
    setShameEntries(prev => prev.map(e => 
      e.id === id ? { ...e, paidRemoval: true } : e
    ));
  }, []);

  return {
    shameEntries,
    addShameEntry,
    updateShameEntry,
    deleteShameEntry,
    deleteShameEntriesBulk,
    markAsPaid,
  };
}

export function useAdminSettings() {
  const [settings, setSettings] = useState<AdminSettings>(() => {
    return loadFromStorage<AdminSettings>(STORAGE_KEYS.settings, DEFAULT_SETTINGS);
  });

  useEffect(() => {
    saveToStorage(STORAGE_KEYS.settings, settings);
  }, [settings]);

  const updateSettings = useCallback((updates: Partial<AdminSettings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
  }, []);

  return { settings, updateSettings };
}

export function useAdminAuth() {
  const [adminState, setAdminState] = useState<AdminState>(() => {
    return loadFromStorage<AdminState>(STORAGE_KEYS.admin, {
      isLoggedIn: false,
      loginAttempts: 0,
      email: 'ali.jasser@aol.com',
    });
  });

  useEffect(() => {
    saveToStorage(STORAGE_KEYS.admin, adminState);
  }, [adminState]);

  const login = useCallback((email: string, password: string): boolean => {
    if (adminState.loginAttempts >= 3) return false;
    
    const correctPassword = 'ChickenAdmin2024!';
    
    if (email === 'ali.jasser@aol.com' && password === correctPassword) {
      setAdminState({ isLoggedIn: true, loginAttempts: 0, email });
      return true;
    } else {
      setAdminState(prev => ({
        ...prev,
        loginAttempts: prev.loginAttempts + 1,
      }));
      return false;
    }
  }, [adminState.loginAttempts]);

  const logout = useCallback(() => {
    setAdminState({
      isLoggedIn: false,
      loginAttempts: 0,
      email: 'ali.jasser@aol.com',
    });
  }, []);

  const resetAttempts = useCallback(() => {
    setAdminState(prev => ({ ...prev, loginAttempts: 0 }));
  }, []);

  return {
    adminState,
    login,
    logout,
    resetAttempts,
    isLockedOut: adminState.loginAttempts >= 3,
    remainingAttempts: Math.max(0, 3 - adminState.loginAttempts),
  };
}
