export interface TeamChallenge {
  id: string;
  challengerTeam: string;
  challengerDiscord?: string;
  challengerTwitch?: string;
  challengerPlatformId?: string;
  targetTeam: string;
  targetDiscord?: string;
  targetTwitch?: string;
  targetPlatformId?: string;
  game: string;
  battleType: string;
  stakeAmount: number;
  createdAt: string;
  responseDeadlineHours: number;
  status: 'pending' | 'confirmed' | 'expired' | 'completed';
  acceptedAt?: string;
  completedAt?: string;
  winner?: string;
  notes?: string;
}

export interface ShameEntry {
  id: string;
  teamName: string;
  discord?: string;
  twitch?: string;
  platformId?: string;
  game: string;
  battleType: string;
  challengerTeam: string;
  expiredAt: string;
  removalFee: number;
  paidRemoval: boolean;
  notes?: string;
}

export interface AdminSettings {
  defaultResponseHours: number;
  admissionFee: number;
  removalFee: number;
  whatsappNumber: string;
  telegramLink: string;
}

export interface AdminState {
  isLoggedIn: boolean;
  loginAttempts: number;
  email: string;
}
